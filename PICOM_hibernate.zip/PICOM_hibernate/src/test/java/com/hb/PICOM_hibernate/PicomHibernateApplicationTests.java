package com.hb.PICOM_hibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PicomHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
