package com.hb.PICOM_hibernate.buisness;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "country")
public class Country {
    @Id
    @Column(name = "country_code", nullable = false, length = 3)
    private String id;

    @Column(name = "country_name", nullable = false, length = 250)
    private String countryName;


    @OneToMany(mappedBy = "idCountry")
    private List<City> cities;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

}