package com.hb.PICOM_hibernate.buisness;

import javax.persistence.*;


import java.time.Instant;
import java.util.List;

@Entity
@Table(name = "advertisment")
public class Advertisment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ad_id", nullable = false)
    private Integer id;

    @Column(name = "ad_name")
    private String adName;

    @Column(name = "ad_created_at", nullable = false)
    private Instant adCreatedAt;

    @Column(name = "ad_started_at", nullable = false)
    private Instant adStartedAt;

    @Column(name = "nb_days", nullable = false)
    private Integer nbDays;

    @Lob
    @Column(name = "ad_img_html")
    private String adImgHtml;

    @Column(name = "ad_img_alt")
    private String adImgAlt;

    @Column(name = "paid_at", nullable = false)
    private Instant paidAt;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_user", nullable = false)
    private User idUser;

    @OneToMany(mappedBy = "idAd")
    private List<Invoice> invoices;

    @OneToMany(mappedBy = "idAd")
    private List<TimeSlotList> timeSlotLists;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAdName() {
        return adName;
    }

    public void setAdName(String adName) {
        this.adName = adName;
    }

    public Instant getAdCreatedAt() {
        return adCreatedAt;
    }

    public void setAdCreatedAt(Instant adCreatedAt) {
        this.adCreatedAt = adCreatedAt;
    }

    public Instant getAdStartedAt() {
        return adStartedAt;
    }

    public void setAdStartedAt(Instant adStartedAt) {
        this.adStartedAt = adStartedAt;
    }

    public Integer getNbDays() {
        return nbDays;
    }

    public void setNbDays(Integer nbDays) {
        this.nbDays = nbDays;
    }

    public String getAdImgHtml() {
        return adImgHtml;
    }

    public void setAdImgHtml(String adImgHtml) {
        this.adImgHtml = adImgHtml;
    }

    public String getAdImgAlt() {
        return adImgAlt;
    }

    public void setAdImgAlt(String adImgAlt) {
        this.adImgAlt = adImgAlt;
    }

    public Instant getPaidAt() {
        return paidAt;
    }

    public void setPaidAt(Instant paidAt) {
        this.paidAt = paidAt;
    }

    public User getIdUser() {
        return idUser;
    }

    public void setIdUser(User idUser) {
        this.idUser = idUser;
    }

}