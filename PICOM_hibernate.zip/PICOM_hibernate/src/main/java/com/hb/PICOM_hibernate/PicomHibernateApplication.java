package com.hb.PICOM_hibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PicomHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(PicomHibernateApplication.class, args);
	}

}
